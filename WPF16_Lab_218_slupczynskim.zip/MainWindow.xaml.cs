﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace lab8
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public ObservableCollection<Subtitle> SubtitleList { get; set; }
        public CollectionViewSource ViewSource { get; set; }

        public MainWindow()
        {
            SubtitleList = new ObservableCollection<Subtitle>();
            ViewSource = new CollectionViewSource();
            InitializeComponent();
            DataContext = SubtitleList;
            ViewSource.Source = SubtitleList;
        }

        private void ExitClick(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void DataGrid_AddingNewItem(object sender, AddingNewItemEventArgs e)
        {
            if (SubtitleList.Count == 0)
                return;

            Subtitle.LastTime = SubtitleList.Select(x => x.HideTime).Max();
        }

        //private TimeSpan GetLastTime()
        //{
        //    return SubtitleList.Select(x => x.HideTime).Last();
        //}
    }

    public class Subtitle
    {
        public TimeSpan ShowTime { get; set; }
        public TimeSpan HideTime { get; set; }
        public static TimeSpan LastTime { get; set; }
        public string Text { get; set; }
        public string Translation { get; set; }

        public Subtitle() 
        { 
            ShowTime = LastTime;
            HideTime = LastTime;
            Text = string.Empty;
            Translation = string.Empty;
        }
    }
}
